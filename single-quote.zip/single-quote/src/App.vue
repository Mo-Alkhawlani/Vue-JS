
<template>
<div class="conten">
  <page-header title="this is my quote" desc="this is body "></page-header>
  <div class="quotes">
    <!-- <single-quote v-for="(quote,idex) in quotes" :key="idex" :text="quote.quoteText"></single-quote> -->
    <single-quote v-for="(quote,idex) in quotes" :key="idex" :text="quote.quoteText"></single-quote>
  </div>
</div>
 
</template>
  <script>
    import PageHeader from './components/PageHeader.vue';
    import SingleQuote from './components/SingleQuote.vue';
    import quotes from '../quotes.json';
    console.log(quotes)
    export  default {
      name:'App',
      components:{
        PageHeader,
        SingleQuote,
      },
      data (){
        return{
          quotes,
        }
      }
    };  
  </script>

<style >
*{
  margin: 0;
  padding: 0;
}
h1 h2 h3 p{
  margin-bottom: 1rem;
}
#app{
  text-align: center;
  color: #2c3e50;
}
.quotes{
  max-width: 80%;
  margin: 1rem auto;
  display: grid;
  grid-template-columns: repeat(2, 1fr); 
  gap: 1rem;
}
</style>
