<template>
  <header class="header">
    <h1 class="header-heading">{{ title }}</h1>
    <p class="header-text">{{desc}}</p>
  </header>
</template>

<script>
  export default{
    name :'PageHeader',
    props :['title','desc']
  }
</script>
<style scoped>
  .header{
    display: block;
    background: #555;
    color: #fff;
    padding: 1rem;
  }
</style>
