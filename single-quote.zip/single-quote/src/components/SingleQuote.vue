<template >
    <dev class="quote">
        <p class="quote-text">{{ text }}</p>
    </dev>
</template>

<script>
export default {
    name : 'SingleQuote',
    props:['text']
}
</script>

<style scoped>
    .quote{
        background: linear-gradient(30deg, #069de9 ,#a9870b,#a1126e ,#890909);
        color: #333;
        padding: 1rem;
        border-radius:10px ;
        margin: 1rem auto;
    }
    .quote-text{
        font-size: 1rem;
        font-weight: bold;
    }
</style>