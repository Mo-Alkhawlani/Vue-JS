<template>
  <div>
  <page-header title="Give me Advice " desc="provide a number and get a piece of advice"></page-header>
  <page-form></page-form>
</div>
</template>

<script>
import PageHeader from './components/PageHeader.vue'
import PageForm from './components/PageForm.vue'
import quotes from '../quotes.json'
  export default{
    name :'App',
    components:{
      PageHeader,
      PageForm,
    },
    provide(){
      return {
        newquotes :this.quotes,
        message:'hhhhhhhhhhhhhhhhhhhheeeeeeeeeeellllllllllllo',
      };
    },
    data() {
      return {
        quotes,
      };
    },
  };
</script>
<style>
@import './assets/main.css';
</style>